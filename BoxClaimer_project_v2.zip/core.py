# -*- coding: utf-8 -*-
"""Core logic: TikTok live watcher + fast box claimer (no UI imports)."""
import asyncio
import http.client
import inspect
import json
import os
import socket
import ssl
import threading
import time
from urllib.parse import urlparse

CLAIM_WORDS = ("box", "treasure", "chest", "luckybox", "redpacket",
               "red_packet", "envelope")
LOG_WORDS = CLAIM_WORDS + ("lucky", "reward", "bonus", "task")
ID_KEYS = ("box_id", "boxid", "treasure_id", "treasureid", "lucky_box_id",
           "luckyboxid", "red_packet_id", "redpacketid", "chest_id", "chestid")


def parse_cookie(raw):
    out = {}
    for part in (raw or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def to_plain(event):
    for fn in ("to_dict", "to_pydict"):
        f = getattr(event, fn, None)
        if callable(f):
            try:
                return f()
            except Exception:
                pass
    try:
        return {k: v for k, v in vars(event).items() if not k.startswith("_")}
    except Exception:
        return {"repr": repr(event)}


def find_box_id(data):
    """Search nested dict/list for a box id key."""
    stack = [data]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            for k, v in cur.items():
                if str(k).lower() in ID_KEYS and v not in (None, "", 0):
                    return str(v)
                if isinstance(v, (dict, list)):
                    stack.append(v)
        elif isinstance(cur, list):
            stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return ""


def apply_session(client, sess):
    sid = sess["sessionid"]
    idc = sess.get("idc") or None
    web = client.web
    if hasattr(web, "set_session"):
        try:
            web.set_session(sid, idc)
        except TypeError:
            web.set_session(sid)
    elif hasattr(web, "set_session_id"):
        web.set_session_id(sid)
    else:
        raise RuntimeError("TikTokLive version has no session support")


async def hold_connection(client, res, t0):
    if isinstance(res, asyncio.Future):
        await res
        return
    if time.time() - t0 > 5:
        return
    for _ in range(20):
        if getattr(client, "connected", False):
            break
        await asyncio.sleep(0.5)
    while getattr(client, "connected", False):
        await asyncio.sleep(1)


class Claimer:
    """Pre-warmed HTTPS connections + zero-delay firing."""

    def __init__(self, cfg, log):
        self.cfg, self.log = cfg, log
        self.pool, self.lock = [], threading.Lock()
        self.seen = set()
        self.running = False
        u = urlparse(cfg.get("url") or "")
        self.scheme, self.host = u.scheme, u.netloc
        self.enabled = bool(u.netloc)
        self.repeat = max(1, int(cfg.get("repeat", 1)))
        self.delay = float(cfg.get("delay_ms", 0)) / 1000.0
        self.timeout = float(cfg.get("timeout", 8))
        try:
            import certifi
            self.ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            self.ctx = ssl.create_default_context()

    def _new_conn(self):
        if self.scheme == "http":
            c = http.client.HTTPConnection(self.host, timeout=self.timeout)
        else:
            c = http.client.HTTPSConnection(self.host, timeout=self.timeout,
                                            context=self.ctx)
        c.connect()
        try:
            c.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass
        return c

    def _keepalive(self):
        # idle connections die on the server side; replace them every 15s
        while self.running:
            time.sleep(15)
            with self.lock:
                old, self.pool = self.pool, []
            for c in old:
                try:
                    c.close()
                except Exception:
                    pass
            self.warm()

    def warm(self):
        if not self.enabled:
            return
        if not self.running:
            self.running = True
            threading.Thread(target=self._keepalive, daemon=True).start()
        def job():
            while True:
                with self.lock:
                    if len(self.pool) >= self.repeat:
                        return
                try:
                    c = self._new_conn()
                except Exception as e:
                    self.log("warm failed: %s" % e)
                    return
                with self.lock:
                    self.pool.append(c)
        threading.Thread(target=job, daemon=True).start()

    def _take(self):
        with self.lock:
            return self.pool.pop() if self.pool else None

    @staticmethod
    def _sub(s, ctx):
        if not isinstance(s, str):
            return s
        for k, v in ctx.items():
            s = s.replace("{%s}" % k, str(v))
        return s

    def fire(self, data, sess, handle, room_id):
        if not self.enabled:
            self.log("claim url empty -> log only")
            return
        box_id = find_box_id(data)
        key = box_id or json.dumps(data, sort_keys=True, default=str)[:200]
        if key in self.seen:
            return
        self.seen.add(key)
        ctx = {"box_id": box_id, "room_id": room_id, "handle": handle,
               "sessionid": sess.get("sessionid", ""), "idc": sess.get("idc", ""),
               "cookie": sess.get("cookie", ""), "ts": int(time.time() * 1000),
               "account": "app",
               "box_json": json.dumps(data, ensure_ascii=False, default=str)}
        u = urlparse(self._sub(self.cfg["url"], ctx))
        path = u.path + ("?" + u.query if u.query else "")
        headers = {k: self._sub(v, ctx) for k, v in
                   (self.cfg.get("headers") or {}).items()}
        body = self._sub(self.cfg.get("body", ""), ctx).encode("utf-8")
        method = (self.cfg.get("method") or "POST").upper()
        t0 = time.perf_counter()
        self.log("BOX detected id=%s -> claiming x%d" % (box_id or "?", self.repeat))
        for i in range(self.repeat):
            threading.Thread(target=self._send, args=(method, path, headers,
                             body, t0, i), daemon=True).start()
            if self.delay:
                time.sleep(self.delay)
        self.warm()

    def _send(self, method, path, headers, body, t0, i):
        conn = self._take()
        try:
            if conn is None:
                conn = self._new_conn()
            conn.request(method, path, body=body or None, headers=headers)
            r = conn.getresponse()
            txt = r.read().decode("utf-8", "replace")
            ms = (time.perf_counter() - t0) * 1000
            need = self.cfg.get("success_contains") or ""
            ok = r.status == 200 and (not need or need in txt)
            self.log("[%d] %s HTTP %d in %.0f ms | %s" %
                     (i + 1, "OK" if ok else "FAIL", r.status, ms, txt[:150]))
        except Exception as e:
            self.log("[%d] error: %s" % (i + 1, e))
        finally:
            try:
                conn.close()
            except Exception:
                pass


class Watcher:
    def __init__(self, handle, sess, cfg, log, on_stop):
        self.handle = handle.lstrip("@")
        self.sess, self.cfg, self.log, self.on_stop = sess, cfg, log, on_stop
        self.claimer = Claimer(cfg, log)
        self.loop = self.task = None
        self.logfile = None

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self):
        if self.loop and self.task:
            self.loop.call_soon_threadsafe(self.task.cancel)

    def _run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._main())
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.log("Error: %s" % e)
        finally:
            try:
                self.loop.close()
            except Exception:
                pass
            self.claimer.running = False
            self.on_stop()

    def _make(self, name, client):
        low = name.lower()
        claim_hit = any(k in low for k in CLAIM_WORDS)
        log_hit = claim_hit or any(k in low for k in LOG_WORDS)
        scan = "unknown" in low

        async def handler(event):
            if not (log_hit or scan):
                return
            data = to_plain(event)
            if scan and not log_hit:
                txt = json.dumps(data, default=str).lower()
                if not any(k in txt for k in ("treasure", "lucky_box", "luckybox",
                                              "red_packet", "redpacket", "chest")):
                    return
                claim_hit_now = True
            else:
                claim_hit_now = claim_hit
            if claim_hit_now:
                self.claimer.fire(data, self.sess, self.handle,
                                  getattr(client, "room_id", ""))
            self.log("event: %s%s" % (name, " [CLAIM]" if claim_hit_now else ""))
            try:
                self.logfile.write(json.dumps({"t": time.time(), "type": name,
                                   "data": data}, ensure_ascii=False,
                                   default=str) + "\n")
                self.logfile.flush()
            except Exception:
                pass
        return handler

    async def _main(self):
        from TikTokLive import TikTokLiveClient
        import TikTokLive.events as ev
        self.task = asyncio.current_task()
        client = TikTokLiveClient(unique_id="@" + self.handle)
        apply_session(client, self.sess)
        path = os.path.join(self.cfg.get("_dir", "."), "events_%s.jsonl" % self.handle)
        self.logfile = open(path, "a", encoding="utf-8")
        n = 0
        for name in dir(ev):
            cls = getattr(ev, name, None)
            if inspect.isclass(cls) and name.endswith("Event"):
                try:
                    client.add_listener(cls, self._make(name, client))
                    n += 1
                except Exception:
                    pass
        self.log("listening to %d event types" % n)
        self.claimer.warm()
        t0 = time.time()
        try:
            try:
                res = await client.connect(fetch_room_info=True)
            except TypeError:
                res = await client.connect()
            await hold_connection(client, res, t0)
        finally:
            try:
                await asyncio.wait_for(client.disconnect(), 3)
            except BaseException:
                pass
            try:
                self.logfile.close()
            except Exception:
                pass
