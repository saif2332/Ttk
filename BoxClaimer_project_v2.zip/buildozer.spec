[app]
title = Box Claimer
package.name = boxclaimer
package.domain = org.koka
source.dir = .
source.include_exts = py,png,json
version = 1.0
icon.filename = %(source.dir)s/icon.png
orientation = portrait
fullscreen = 0
requirements = python3,kivy==2.3.0,pyjnius,android,certifi,openssl,httpx,httpcore,h11,anyio,sniffio,idna,protobuf,pyee,websockets,typing_extensions,TikTokLive
android.permissions = INTERNET,WAKE_LOCK
android.api = 33
android.minapi = 24
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
